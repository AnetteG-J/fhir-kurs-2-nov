# fhir.education.kursig#0.1.0: FHIR-utbildning – Anette G-J

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [FHIR-utbildning – Anette G-J](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
